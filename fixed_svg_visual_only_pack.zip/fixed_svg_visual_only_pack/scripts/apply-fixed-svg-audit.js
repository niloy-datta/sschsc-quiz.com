/**
 * Apply fixed SVG audit map to quiz JSON files.
 * Usage:
 *   node scripts/apply-fixed-svg-audit.js <projectRoot>
 *
 * It traverses JSON files under public/quiz-data and updates/removes image/svg fields
 * according to svg_update_map.json. Back up your repo before running.
 */
const fs = require("fs");
const path = require("path");

const root = process.argv[2] || process.cwd();
const mapPath = path.join(__dirname, "..", "svg_update_map.json");
const updateMap = JSON.parse(fs.readFileSync(mapPath, "utf8"));
const byId = new Map(updateMap.map(x => [x.questionId, x]));

const quizRoot = path.join(root, "public", "quiz-data");
const touched = [];

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const entry of fs.readdirSync(dir)) {
    const p = path.join(dir, entry);
    const st = fs.statSync(p);
    if (st.isDirectory()) out.push(...walk(p));
    else if (entry.endsWith(".json")) out.push(p);
  }
  return out;
}

function patchQuestion(q) {
  const id = q.id || q.questionId;
  if (!id || !byId.has(id)) return false;
  const u = byId.get(id);

  q.visualRequired = u.visualRequired;
  q.imageStatus = u.imageStatus;

  if (u.action === "set_image") {
    q.image = "/" + u.newImage.replace(/^\/?/, "");
    delete q.svg;
    if (u.optionImages && u.optionImages.length && Array.isArray(q.options)) {
      const labels = ["ক","খ","গ","ঘ","A","B","C","D"];
      for (let i = 0; i < q.options.length && i < u.optionImages.length; i++) {
        if (typeof q.options[i] === "object") {
          q.options[i].image = "/" + u.optionImages[i].replace(/^\/?/, "");
        }
      }
    }
  } else {
    delete q.image;
    delete q.svg;
    delete q.imageAlt;
    if (Array.isArray(q.options)) {
      for (const opt of q.options) {
        if (opt && typeof opt === "object") {
          delete opt.image;
          delete opt.svg;
        }
      }
    }
  }

  if (u.imageStatus === "needs_original_figure") {
    q.reviewReason = u.reason;
  } else {
    delete q.reviewReason;
  }
  return true;
}

function recursivePatch(obj) {
  let changed = false;
  if (Array.isArray(obj)) {
    for (const item of obj) changed = recursivePatch(item) || changed;
  } else if (obj && typeof obj === "object") {
    if ((obj.id || obj.questionId) && (obj.question || obj.stem || obj.options)) {
      changed = patchQuestion(obj) || changed;
    }
    for (const key of Object.keys(obj)) {
      changed = recursivePatch(obj[key]) || changed;
    }
  }
  return changed;
}

for (const file of walk(quizRoot)) {
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (recursivePatch(data)) {
      fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
      touched.push(path.relative(root, file));
    }
  } catch (e) {
    console.warn("Skip invalid JSON:", file, e.message);
  }
}

console.log(JSON.stringify({ updatedFiles: touched.length, files: touched }, null, 2));
