# Fixed SVG Visual-Only Pack

This is a corrected replacement for the earlier all-question SVG pack.

## What changed
- Images are **not** generated for every question.
- Theory-only MCQs are marked `not_required`.
- Hidden/underspecified geometry questions are marked `needs_original_figure` instead of receiving fake diagrams.
- Biology diagrams are regenerated as deeper concept-specific SVGs.

## Summary
- Total reviewed items: 2490
- Main SVG generated: 329
- Option SVG generated/copied: 96
- Removed unnecessary old images: 2156
- Needs original figure/manual review: 5
- Deep biology diagrams: 126

## Files
- `images/quiz/premium/` — corrected SVG files only
- `svg_update_map.json` — use this to update question JSON image fields
- `reports/image_audit_report.json` — full audit
- `reports/removed_unnecessary_images.json` — questions where image must be removed
- `reports/needs_original_figure.json` — figure referenced but original board figure is missing
- `reports/biology_deep_diagram_questions.json` — biology diagrams generated with deep templates
- `scripts/apply-fixed-svg-audit.js` — optional Node script to patch your project JSON files

## Integration
Copy the `images` folder to your project's `public/`.
Then run:

```bash
node scripts/apply-fixed-svg-audit.js /path/to/your/project
```

Back up your JSON files before running the script.
